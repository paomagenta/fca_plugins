<?php
extract( shortcode_atts( array(
		'instagram_id' => '',
		'pics_count' => '6',
		'fts_rotate_feed' => 'no',
		'fts_rotate_poh' =>'true',
		'fts_rotate_speed' =>'200',
		'fts_rotate_fx' =>'fade',
		'fts_rotate_random' => 'no'
), $atts ) );;
?>