=== Feed Them Social Premium Extension ===
Contributors: SlickRemix
Tags:  social, social plugin, facebook, facebook plugin, facebook group, facebook page, twitter, twitter plugin, instagram, instagram plugin, youtube, youtube plugin, feed me social, feed, shortcode, slickremix, pinterest
Requires at least: 3.4.0
Tested up to: 3.8.1
Stable tag: 1.2.4
License: GPLv2 or later


Easily add Instagram, Facebook Group, Facebook Page, Twitter, YouTube and now Pinterest Feeds to any page, post or widget!

== Description ==
Easily add Instagram, Facebook Group, Facebook Page, Twitter, YouTube and now Pinterest Feeds to any page, post or widget!

= Features include the following: =
  * Add a single or multiple feeds to any post or page!
  * Easily Generate all the shortcodes you need for any feed!
  * Responsive social feeds! 
  * With [Premium Extension](http://www.slickremix.com/product/feed-them-social-premium-extension/) you can set how many posts, pictures, or tweets for each individual social feed!
  * …and much more!
   
== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

== Changelog ==
= Version 1.2.4 March 20th, 2014 =
 * FIXED: Facebook Page shortcode now shows the words=45 by default or whatever number you choose.

= Version 1.2.3 February 15th, 2014 =
 * FIXED: Instagram post count not spitting out correctly.
 * FIXED: Facebook Event Feed widget has now been created.
 * ADDED: Facebook Page now can be sorted by pages posts only!
 
= Version 1.2.2 February 11th, 2014 =
 * ADDED: Facebook Event Feed.

= Version 1.2.1 November 13th, 2013 =
 * FIXED: More Pintrest conflicting issues with NextGen Gallery plugin. Fixes Fatal Error on activation.

= Version 1.2.0 October 16th, 2013 =
 * FIX: Pintrest conflicting issue with NextGen Gallery plugin.

= Version 1.1.9 September 15th, 2013 =
 * MAJOR FIX: Removed Top Quark plugin update status from feed-them-premium.php as it is added in our plugin automatically when uploaded now on slickremix.com. This was causing text from the feed-them-premium.php to be written on all the pages. Not good. All fixed now.

= Version 1.1.8 September 15th, 2013 =
 * FIXED: Changed function name 'file_get_html' for Pinterest feed as it was causing a conflict with the Lightbox Plus wordpress plugin. Thanks to [ragstein](http://www.slickremix.com/support-forum/wordpress-plugins-group3/feed-them-social-forum9/fatal-error-when-trying-to-activate-thread135/)for pointing this out on our support forum.

= Version 1.1.7 September 9th, 2013 =
 * ADDED: Facebook Page feed. Also allows you to choose to add a title or description of your Facebook page. Widget included too.

= Version 1.1.6 September 1st, 2013 =
 * MAJOR FIX: Facebook group feed had some out of order divs causing formatting issues that were added in 1.1.5 version, they have been adjusted now. This should fix the widget area as well.
 
= Version 1.1.5 August 12th, 2013 =
 * ADDED: Option to hide the Group Title or Description for Facebook Groups.
 
= Version 1.1.4 August 1st, 2013 =
 * ADDED: Pinterest Feed and Widgets

= Version 1.1.3 June 4rd, 2013 =
 * FIXED: Misc. YouTube style fixes for overlay in Chrome and widget style fixes for FireFox.

= Version 1.1.2 June 3rd, 2013 =
 * FIXED: Made a warning that all users must have free version installed and activated.

= Version 1.1.1 February 15th, 2013 =
 * NEW: Widget support for all feeds. You can now also paste shortcodes into a text widget and they will appear.

= Version 1.1.0 =
 * NEW: YouTube feed added to plugin! Includes Html 5 Pop-Up.

= Version 1.0.0 =
 * Initial Release

== Frequently Asked Questions ==

You can find answers to your questions, suggest a feed, or just drop us a line at our [Support Forum](http://www.slickremix.com/support-forum).

= Are there Extensions for this plugin? =

Yes. Currently we have [1 Premium Extension](http://www.slickremix.com/product/feed-them-social-premium-extension/).

== Screenshots ==
