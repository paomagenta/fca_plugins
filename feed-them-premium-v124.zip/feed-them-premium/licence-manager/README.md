digital_licencing
=================

Licencing and auto updating for Jigoshop downloadable products
