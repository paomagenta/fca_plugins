<div class="feed-them-social-admin-input-wrap">
  <div class="feed-them-social-admin-input-label"># of Tweets (optional)</div>
  <input type="text" id="tweets_count" class="feed-them-social-admin-input" value="" />
<div class="clear"></div>
</div><!--/feed-them-social-admin-input-wrap-->