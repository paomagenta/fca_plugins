<div class="feed-them-social-admin-input-wrap youtube_name">
    <div class="feed-them-social-admin-input-label">Youtube Name (required)</div>
    <input type="text" id="youtube_name" class="feed-them-social-admin-input" value="" />
<div class="clear"></div>
  </div><!--/feed-them-social-admin-input-wrap-->
  
  <div class="feed-them-social-admin-input-wrap youtube_vid_count">
    <div class="feed-them-social-admin-input-label"># of videos (required)</div>
    <input type="text" id="youtube_vid_count" class="feed-them-social-admin-input" value="" />
<div class="clear"></div>
  </div><!--/feed-them-social-admin-input-wrap-->
  
  <div class="feed-them-social-admin-input-wrap youtube_columns">
    <div class="feed-them-social-admin-input-label"># of videos in each row?</div>
    <select id="youtube_columns" class="feed-them-social-admin-input" size="1">
      <option value="1">1 video per row</option>
      <option value="2">2 videos per row</option>
      <option value="3">3 videos per row</option>
      <option value="4">4 videos per row</option>
    </select>
<div class="clear"></div>
  </div><!--/feed-them-social-admin-input-wrap-->
  
  <div class="feed-them-social-admin-input-wrap youtube_first_video">
    <div class="feed-them-social-admin-input-label">Display First video full size?</div>
    <select id="youtube_first_video" class="feed-them-social-admin-input" size="1">
      <option value="yes">Yes</option>
      <option value="no">No</option>
    </select>
<div class="clear"></div>
  </div><!--/feed-them-social-admin-input-wrap-->
  
<?php 
if(is_plugin_active('fts-rotate/fts-rotate.php')) {
	include('../wp-content/plugins/fts-rotate/admin/fts-rotate-settings-fields.php');
}
?>
  
   <input type="button" class="feed-them-social-admin-submit-btn" value="Generate youtube Shortcode" onclick="updateTextArea_youtube();" tabindex="4" style="margin-right:1em;" />
      <div class="feed-them-social-admin-input-wrap final-shortcode-textarea">
      
      	<h4>Copy the ShortCode below and paste it on a page or post that you want to display your feed.</h4>
      
        <div class="feed-them-social-admin-input-label">YouTube Feed Shortcode</div>
        <input class="copyme youtube-final-shortcode feed-them-social-admin-input" value="" />
    <div class="clear"></div>
      </div><!--/feed-them-social-admin-input-wrap-->